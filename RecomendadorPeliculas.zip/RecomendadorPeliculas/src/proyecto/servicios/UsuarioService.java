package proyecto.servicios;

import proyecto.modelos.Usuario;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;

public class UsuarioService {
    private Map<Integer, Usuario> usuarios = new HashMap<>();

    public void agregarUsuario(Usuario u) {
        usuarios.put(u.getId(), u);
    }

    public Usuario obtenerUsuario(int id) {
        return usuarios.get(id);
    }

    public Collection<Usuario> obtenerTodos() {
        return usuarios.values();
    }
}
