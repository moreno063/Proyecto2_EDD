package proyecto.servicios;

import proyecto.estructura.SparseMatrix;

import java.util.ArrayList;
import java.util.List;

public class RatingService {

    private final SparseMatrix ratings;

    public RatingService(SparseMatrix ratings) {
        this.ratings = ratings;
    }

    public void addRating(int userId, int movieId, double rating) {
        ratings.add(userId, movieId, rating);
    }

    public double getRating(int userId, int movieId) {
        return ratings.get(userId, movieId);
    }

    public boolean hasRating(int userId, int movieId) {
        return ratings.exists(userId, movieId);
    }

    // Obtener todas las películas calificadas por un usuario
    public List<Integer> getMoviesRatedByUser(int userId) {
        List<Integer> movies = new ArrayList<>();

        for (int[] entry : ratings.getAll()) {
            int user = entry[0];
            int movie = entry[1];
            double rating = entry[2];

            if (user == userId) {
                movies.add(movie);
            }
        }

        return movies;
    }
}
