package proyecto.servicios;

import proyecto.estructura.AVLTree;
import proyecto.modelos.Pelicula;
import java.util.List;

public class PeliculaService {
    private AVLTree tree = new AVLTree();

    public void agregarPelicula(Pelicula p) {
        tree.insertar(p);
    }

    public Pelicula buscarPorTitulo(String titulo) {
        return tree.buscarPorTitulo(titulo);
    }

    public List<Pelicula> listarOrdenado() {
        return tree.inOrder();
    }
}
