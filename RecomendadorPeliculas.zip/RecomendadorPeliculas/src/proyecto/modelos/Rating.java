package proyecto.modelos;

public class Rating {
    private int idUsuario;
    private int idPelicula;
    private int valor; // 1-5

    public Rating(int idUsuario, int idPelicula, int valor) {
        this.idUsuario = idUsuario;
        this.idPelicula = idPelicula;
        this.valor = valor;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public int getIdPelicula() {
        return idPelicula;
    }

    public int getValor() {
        return valor;
    }
}
