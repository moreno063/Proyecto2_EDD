package proyecto.modelos;

import java.util.HashSet;
import java.util.Set;

public class Usuario {
    private int id;
    private String nombre;
    private String generoFavorito;
    private Set<Integer> peliculasVistas; // ids de peliculas

    public Usuario(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.generoFavorito = "";
        this.peliculasVistas = new HashSet<>();
    }

    public Usuario(int id, String nombre, String generoFavorito) {
        this.id = id;
        this.nombre = nombre;
        this.generoFavorito = generoFavorito;
        this.peliculasVistas = new HashSet<>();
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getGeneroFavorito() {
        return generoFavorito;
    }

    public void setGeneroFavorito(String genero) {
        this.generoFavorito = genero;
    }

    public void setPeliculasVistas(Set<Integer> vistas) {
        this.peliculasVistas = vistas;
    }

    public void addVisto(int idPelicula) {
        peliculasVistas.add(idPelicula);
    }

    public boolean vio(int idPelicula) {
        return peliculasVistas.contains(idPelicula);
    }

    public Set<Integer> getPeliculasVistas() {
        return peliculasVistas;
    }

    @Override
    public String toString() {
        return String.format("Usuario[%d] %s - generoFavorito=%s - vistas=%d",
                id, nombre, generoFavorito, peliculasVistas.size());
    }
}