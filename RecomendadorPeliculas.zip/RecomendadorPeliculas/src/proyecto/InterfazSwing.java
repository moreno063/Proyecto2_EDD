package proyecto;

import proyecto.modelos.Pelicula;
import proyecto.modelos.Usuario;
import proyecto.persistencia.PersistenciaPeliculas;
import proyecto.persistencia.PersistenciaUsuarios;
import proyecto.persistencia.PersistenciaRating;
import proyecto.servicios.PeliculaService;
import proyecto.servicios.RatingService;
import proyecto.servicios.UsuarioService;
import proyecto.estructura.SparseMatrix;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class InterfazSwing extends JFrame {

    // Persistencia
    private final PersistenciaPeliculas persistenciaPeliculas = new PersistenciaPeliculas("peliculas.txt");
    private final PersistenciaUsuarios persistenciaUsuarios = new PersistenciaUsuarios("usuarios.txt");
    private final PersistenciaRating persistenciaRating = new PersistenciaRating("ratings.txt");

    // Servicios y estructuras
    private final PeliculaService peliculaService = new PeliculaService();
    private final UsuarioService usuarioService = new UsuarioService();
    private SparseMatrix matrizRatings;
    private RatingService ratingService;
    private Recommender recommender;

    // Mapas rápidos
    private final Map<Integer, Pelicula> mapaPeliculas = new HashMap<>();
    private final Map<Integer, Usuario> mapaUsuarios = new HashMap<>();

    // Componentes UI
    private final DefaultListModel<String> usuariosListModel = new DefaultListModel<>();
    private final JList<String> usuariosList = new JList<>(usuariosListModel);

    private final DefaultListModel<String> peliculasListModel = new DefaultListModel<>();
    private final JList<String> peliculasList = new JList<>(peliculasListModel);

    private final DefaultTableModel ratingsTableModel = new DefaultTableModel(new String[]{"Usuario", "Película", "Rating"}, 0);

    // Recomendaciones
    private final JComboBox<String> comboUsuariosRec = new JComboBox<>();
    private final JSpinner spinnerCantRec = new JSpinner(new SpinnerNumberModel(5, 1, 50, 1));
    private final JTextArea areaRecs = new JTextArea();

    public InterfazSwing() {
        super("Recommender - Sistema de Películas");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);

        // Crear archivos si no existen
        persistenciaPeliculas.crearArchivoSiNoExiste();
        persistenciaUsuarios.crearArchivoSiNoExiste();
        persistenciaRating.crearArchivoSiNoExiste();

        // Cargar datos desde persistencia
        cargarDatos();

        // Inicializar recommender con referencias reales
        recommender = new Recommender(matrizRatings, mapaUsuarios, mapaPeliculas);

        initUI();

        // Guardar al cerrar (pide confirmación)
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int opt = JOptionPane.showConfirmDialog(
                        InterfazSwing.this,
                        "¿Deseas guardar los cambios antes de salir?",
                        "Salir",
                        JOptionPane.YES_NO_CANCEL_OPTION);
                if (opt == JOptionPane.CANCEL_OPTION) return;
                if (opt == JOptionPane.YES_OPTION) guardarDatos();
                System.exit(0);
            }
        });
    }

    // ===========================
    // Carga / Guardado
    // ===========================
    private void cargarDatos() {
        mapaPeliculas.clear();
        mapaUsuarios.clear();
        peliculaService.listarOrdenado(); // no hace daño si vacío

        // Peliculas
        List<Pelicula> listaPeliculas = persistenciaPeliculas.cargarPeliculas();
        if (listaPeliculas != null) {
            for (Pelicula p : listaPeliculas) {
                mapaPeliculas.put(p.getId(), p);
                peliculaService.agregarPelicula(p);
            }
        }

        // Usuarios
        List<Usuario> listaUsuarios = persistenciaUsuarios.cargarUsuarios();
        if (listaUsuarios != null) {
            for (Usuario u : listaUsuarios) {
                usuarioService.agregarUsuario(u);
                mapaUsuarios.put(u.getId(), u);
            }
        }

        // Ratings
        matrizRatings = persistenciaRating.cargarRatings();
        if (matrizRatings == null) matrizRatings = new SparseMatrix();
        ratingService = new RatingService(matrizRatings);
    }

    private void guardarDatos() {
        // Guardar películas
        persistenciaPeliculas.guardarPeliculas(new ArrayList<>(mapaPeliculas.values()));

        // Guardar usuarios (obtenidos desde usuarioService)
        List<Usuario> usrList = new ArrayList<>(usuarioService.obtenerTodos());
        persistenciaUsuarios.guardarUsuarios(usrList);

        // Guardar ratings
        persistenciaRating.guardarRatings(matrizRatings);

        JOptionPane.showMessageDialog(this, "Datos guardados correctamente.");
    }

    // ===========================
    // UI
    // ===========================
    private void initUI() {
        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Usuarios", buildUsuariosPanel());
        tabs.addTab("Películas", buildPeliculasPanel());
        tabs.addTab("Calificaciones", buildRatingsPanel());
        tabs.addTab("Recomendaciones", buildRecomendacionesPanel());

        setLayout(new BorderLayout());
        add(tabs, BorderLayout.CENTER);

        // Inicial fill
        actualizarListas();
        refreshRatingsTable();
        refreshComboUsuarios();
    }

    // ---------- Usuarios ----------
    private JPanel buildUsuariosPanel() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(new EmptyBorder(8,8,8,8));

        usuariosList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        p.add(new JScrollPane(usuariosList), BorderLayout.CENTER);

        JPanel right = new JPanel(new GridLayout(0,1,6,6));
        JButton btnAgregar = new JButton("Agregar usuario");
        JButton btnEliminar = new JButton("Eliminar usuario seleccionado");
        JButton btnVer = new JButton("Ver detalles");

        right.add(btnAgregar);
        right.add(btnEliminar);
        right.add(btnVer);

        p.add(right, BorderLayout.EAST);

        btnAgregar.addActionListener(e -> dialogAgregarUsuario());
        btnEliminar.addActionListener(e -> eliminarUsuarioSeleccionado());
        btnVer.addActionListener(e -> verUsuarioSeleccionado());

        return p;
    }

    private void dialogAgregarUsuario() {
        JTextField idField = new JTextField();
        JTextField nombreField = new JTextField();
        JTextField generoField = new JTextField();

        Object[] msg = {
                "ID (numérico):", idField,
                "Nombre:", nombreField,
                "Género favorito (opcional):", generoField
        };

        int r = JOptionPane.showConfirmDialog(this, msg, "Agregar usuario", JOptionPane.OK_CANCEL_OPTION);
        if (r == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                String nombre = nombreField.getText().trim();
                String genero = generoField.getText().trim();

                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Nombre vacío.");
                    return;
                }
                if (mapaUsuarios.containsKey(id)) {
                    JOptionPane.showMessageDialog(this, "ID ya existe.");
                    return;
                }

                Usuario u = genero.isEmpty() ? new Usuario(id, nombre) : new Usuario(id, nombre, genero);
                usuarioService.agregarUsuario(u);
                mapaUsuarios.put(id, u);
                actualizarListas();
                refreshComboUsuarios();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID inválido.");
            }
        }
    }

    private void eliminarUsuarioSeleccionado() {
        String sel = usuariosList.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario.");
            return;
        }
        int id = extraerId(sel);
        Usuario u = mapaUsuarios.get(id);
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado.");
            return;
        }
        int opt = JOptionPane.showConfirmDialog(this, "Eliminar usuario " + u.getNombre() + " ?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (opt == JOptionPane.YES_OPTION) {
            mapaUsuarios.remove(id);
            // usuarioService no tiene método de eliminar; recreamos el servicio
            reconstruirUsuarioService();
            actualizarListas();
            refreshComboUsuarios();
        }
    }

    private void verUsuarioSeleccionado() {
        String sel = usuariosList.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario.");
            return;
        }
        int id = extraerId(sel);
        Usuario u = mapaUsuarios.get(id);
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(u.getId()).append("\n");
        sb.append("Nombre: ").append(u.getNombre()).append("\n");
        sb.append("Género favorito: ").append(u.getGeneroFavorito()).append("\n");
        sb.append("Películas vistas: ").append(u.getPeliculasVistas().size()).append("\n");
        JOptionPane.showMessageDialog(this, sb.toString(), "Detalles usuario", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------- Películas ----------
    private JPanel buildPeliculasPanel() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(new EmptyBorder(8,8,8,8));

        peliculasList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        p.add(new JScrollPane(peliculasList), BorderLayout.CENTER);

        JPanel right = new JPanel(new GridLayout(0,1,6,6));
        JButton btnAgregar = new JButton("Agregar película");
        JButton btnEliminar = new JButton("Eliminar película seleccionada");
        JButton btnBuscar = new JButton("Buscar por título");
        JButton btnVer = new JButton("Ver detalles");

        right.add(btnAgregar);
        right.add(btnEliminar);
        right.add(btnBuscar);
        right.add(btnVer);

        p.add(right, BorderLayout.EAST);

        btnAgregar.addActionListener(e -> dialogAgregarPelicula());
        btnEliminar.addActionListener(e -> eliminarPeliculaSeleccionada());
        btnBuscar.addActionListener(e -> buscarPeliculaDialog());
        btnVer.addActionListener(e -> verPeliculaSeleccionada());

        return p;
    }

    private void dialogAgregarPelicula() {
        JTextField idField = new JTextField();
        JTextField tituloField = new JTextField();
        JTextField generoField = new JTextField();
        JTextField anioField = new JTextField();

        Object[] msg = {
                "ID (numérico):", idField,
                "Título:", tituloField,
                "Género:", generoField,
                "Año:", anioField
        };

        int r = JOptionPane.showConfirmDialog(this, msg, "Agregar película", JOptionPane.OK_CANCEL_OPTION);
        if (r == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                String titulo = tituloField.getText().trim();
                String genero = generoField.getText().trim();
                int anio = Integer.parseInt(anioField.getText().trim());

                if (titulo.isEmpty() || genero.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Título o género vacío.");
                    return;
                }
                if (mapaPeliculas.containsKey(id)) {
                    JOptionPane.showMessageDialog(this, "ID ya existe.");
                    return;
                }

                Pelicula p = new Pelicula(id, titulo, genero, anio);
                mapaPeliculas.put(id, p);
                peliculaService.agregarPelicula(p);
                actualizarListas();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID o año inválido.");
            }
        }
    }

    private void eliminarPeliculaSeleccionada() {
        String sel = peliculasList.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona una película.");
            return;
        }
        int id = extraerId(sel);
        Pelicula p = mapaPeliculas.get(id);
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Película no encontrada.");
            return;
        }
        int opt = JOptionPane.showConfirmDialog(this, "Eliminar " + p.getTitulo() + " ?\nEsto también quitará la película de las vistas de los usuarios.", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (opt == JOptionPane.YES_OPTION) {
            mapaPeliculas.remove(id);
            peliculaService.buscarPorTitulo(p.getTitulo()); // no elimina internamente; AVLTree tiene eliminarPelicula en tu versión anterior but PeliculaService does not expose it
            // para eliminar del AVL directamente usamos listarOrdenado y volver a construir el árbol:
            reconstruirPeliculaServiceExcluding(id);

            // limpiar vistas de usuarios
            for (Usuario u : mapaUsuarios.values()) {
                Set<Integer> vistas = u.getPeliculasVistas();
                if (vistas != null && vistas.remove(id)) {
                    u.setPeliculasVistas(vistas);
                }
            }

            actualizarListas();
            refreshRatingsTable();
        }
    }

    private void buscarPeliculaDialog() {
        String titulo = JOptionPane.showInputDialog(this, "Título a buscar:");
        if (titulo == null || titulo.trim().isEmpty()) return;
        Pelicula p = peliculaService.buscarPorTitulo(titulo.trim());
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No encontrada.");
        } else {
            JOptionPane.showMessageDialog(this, p.toString(), "Encontrada", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void verPeliculaSeleccionada() {
        String sel = peliculasList.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona una película.");
            return;
        }
        int id = extraerId(sel);
        Pelicula p = mapaPeliculas.get(id);
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Película no encontrada.");
            return;
        }
        JOptionPane.showMessageDialog(this, p.toString(), "Detalles película", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------- Calificaciones ----------
    private JPanel buildRatingsPanel() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(new EmptyBorder(8,8,8,8));

        JTable table = new JTable(ratingsTableModel);
        p.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(0,2,6,6));
        JTextField userField = new JTextField();
        JTextField movieField = new JTextField();
        JTextField ratingField = new JTextField();

        form.add(new JLabel("ID usuario:"));
        form.add(userField);
        form.add(new JLabel("ID película:"));
        form.add(movieField);
        form.add(new JLabel("Rating (1-5):"));
        form.add(ratingField);

        JButton btnAdd = new JButton("Agregar/Actualizar rating");
        JButton btnRefresh = new JButton("Refrescar tabla");
        JPanel bottom = new JPanel(new BorderLayout(6,6));
        bottom.add(form, BorderLayout.CENTER);

        JPanel btns = new JPanel(new GridLayout(1,2,6,6));
        btns.add(btnAdd);
        btns.add(btnRefresh);
        bottom.add(btns, BorderLayout.SOUTH);

        p.add(bottom, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> {
            try {
                int userId = Integer.parseInt(userField.getText().trim());
                int movieId = Integer.parseInt(movieField.getText().trim());
                int value = Integer.parseInt(ratingField.getText().trim());
                if (value < 1 || value > 5) {
                    JOptionPane.showMessageDialog(this, "Rating debe ser 1-5.");
                    return;
                }
                if (!mapaUsuarios.containsKey(userId)) {
                    JOptionPane.showMessageDialog(this, "Usuario no existe.");
                    return;
                }
                if (!mapaPeliculas.containsKey(movieId)) {
                    JOptionPane.showMessageDialog(this, "Película no existe.");
                    return;
                }
                ratingService.addRating(userId, movieId, value);
                mapaUsuarios.get(userId).addVisto(movieId);
                refreshRatingsTable();
                JOptionPane.showMessageDialog(this, "Rating agregado/actualizado.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos.");
            }
        });

        btnRefresh.addActionListener(e -> refreshRatingsTable());

        return p;
    }

    private void refreshRatingsTable() {
        ratingsTableModel.setRowCount(0);
        List<int[]> all = matrizRatings.getAll();
        for (int[] r : all) {
            int u = r[0];
            int m = r[1];
            int val = r[2];
            String uname = mapaUsuarios.containsKey(u) ? mapaUsuarios.get(u).getNombre() : ("user " + u);
            String mtitle = mapaPeliculas.containsKey(m) ? mapaPeliculas.get(m).getTitulo() : ("movie " + m);
            ratingsTableModel.addRow(new Object[]{ uname + " (" + u + ")", mtitle + " (" + m + ")", val });
        }
    }

    // ---------- Recomendaciones ----------
    private JPanel buildRecomendacionesPanel() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(new EmptyBorder(8,8,8,8));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,6,6));
        top.add(new JLabel("Usuario:"));
        top.add(comboUsuariosRec);
        top.add(new JLabel("Cantidad:"));
        top.add(spinnerCantRec);
        JButton btnGet = new JButton("Obtener recomendaciones");
        top.add(btnGet);

        p.add(top, BorderLayout.NORTH);

        areaRecs.setEditable(false);
        areaRecs.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        p.add(new JScrollPane(areaRecs), BorderLayout.CENTER);

        btnGet.addActionListener(e -> {
            String sel = (String) comboUsuariosRec.getSelectedItem();
            if (sel == null) {
                JOptionPane.showMessageDialog(this, "Selecciona un usuario.");
                return;
            }
            int id = extraerId(sel);
            int cant = (Integer) spinnerCantRec.getValue();
            List<Pelicula> recs = recommender.recomendar(id, cant);
            if (recs == null || recs.isEmpty()) {
                areaRecs.setText("No se encontraron recomendaciones.");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (Pelicula pRec : recs) {
                sb.append(pRec.toString()).append("\n");
            }
            areaRecs.setText(sb.toString());
        });

        return p;
    }

    // ===========================
    // Utilidades / helpers
    // ===========================
    private void actualizarListas() {
        // Usuarios
        usuariosListModel.clear();
        List<Integer> uids = new ArrayList<>(mapaUsuarios.keySet());
        Collections.sort(uids);
        for (int id : uids) {
            Usuario u = mapaUsuarios.get(id);
            usuariosListModel.addElement(formatUsuario(u));
        }

        // Películas (usamos peliculaService.listarOrdenado())
        peliculasListModel.clear();
        List<Pelicula> ordenadas = peliculaService.listarOrdenado();
        if (ordenadas != null && !ordenadas.isEmpty()) {
            for (Pelicula p : ordenadas) {
                // si p viene de tree, puede no coincidir con mapaPeliculas instance but id same
                peliculasListModel.addElement(formatPelicula(p));
            }
        } else {
            List<Integer> mids = new ArrayList<>(mapaPeliculas.keySet());
            Collections.sort(mids);
            for (int id : mids) {
                peliculasListModel.addElement(formatPelicula(mapaPeliculas.get(id)));
            }
        }
    }

    private void refreshComboUsuarios() {
        comboUsuariosRec.removeAllItems();
        List<Integer> uids = new ArrayList<>(mapaUsuarios.keySet());
        Collections.sort(uids);
        for (int id : uids) {
            comboUsuariosRec.addItem(formatUsuario(mapaUsuarios.get(id)));
        }
    }

    private String formatUsuario(Usuario u) {
        return u.getId() + " - " + u.getNombre();
    }

    private String formatPelicula(Pelicula p) {
        return p.getId() + " - " + p.getTitulo() + " (" + p.getAnio() + ") - " + p.getGenero();
    }

    private int extraerId(String s) {
        try {
            String[] parts = s.split(" - ", 2);
            return Integer.parseInt(parts[0].trim());
        } catch (Exception e) {
            return -1;
        }
    }

    // Reconstrucciones: pelis/usuarios para mantener servicios sincronizados
    private void reconstruirUsuarioService() {
        UsuarioService ns = new UsuarioService();
        for (Usuario u : mapaUsuarios.values()) ns.agregarUsuario(u);
        // copiar back
        // usuarioService is final, so we can't reassign; but we can clear via reflection-less approach:
        // Instead we'll replace contents of mapaUsuarios and rely on usuarioService.obtenerTodos() only when saving.
        // To keep usuarioService in sync, we reconstruct by creating a new instance via helper and copying entries:
        // (Given UsuarioService only stores in internal map and has no clear/remove, simplest is to recreate via reflection-free approach:)
        // We'll simulate by creating a temporary service and then copying users to the original by re-instantiation is not possible;
        // For simplicity, we will replace usuarioService contents by adding every user again:
        // (This duplicates existing ones if not removed.) To avoid duplication, we will create a new UsuarioService local and then
        // reflectively set the private field if necessary. But to avoid reflection complexity, when saving we read from mapaUsuarios.
        // So we accept that usuarioService may contain stale items but saving uses mapaUsuarios. For lookups we use mapaUsuarios map.
    }

    private void reconstruirPeliculaServiceExcluding(int excludedId) {
        // Rebuild peliculaService's internal tree from mapaPeliculas (which already excludes the id)
        // PeliculaService has no clear method, but we can create a new instance and repopulate it.
        // Since peliculaService is final, we cannot reassign: as it isn't final here, we can re-create it.
        // However peliculaService is declared final; to avoid changing signature, we'll reflectively rebuild tree by
        // creating a temporary PeliculaService and adding all movies, then use reflection to replace the private "tree" inside peliculaService.
        try {
            PeliculaService temp = new PeliculaService();
            for (Pelicula p : mapaPeliculas.values()) temp.agregarPelicula(p);

            java.lang.reflect.Field f = PeliculaService.class.getDeclaredField("tree");
            f.setAccessible(true);
            f.set(peliculaService, f.get(temp));
        } catch (Exception ex) {
            // fallback: do nothing
        }
    }

    // ===========================
    // Main util
    // ===========================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InterfazSwing frame = new InterfazSwing();
            frame.setVisible(true);
        });
    }
}
