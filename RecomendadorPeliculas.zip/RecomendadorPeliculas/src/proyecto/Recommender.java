package proyecto;

import proyecto.modelos.Pelicula;
import proyecto.modelos.Usuario;

import proyecto.estructura.SparseMatrix;

import java.util.*;

public class Recommender {

    private final SparseMatrix ratings;
    private final Map<Integer, Usuario> usuarios;
    private final Map<Integer, Pelicula> peliculas;

    public Recommender(SparseMatrix ratings,
            Map<Integer, Usuario> usuarios,
            Map<Integer, Pelicula> peliculas) {
        this.ratings = ratings;
        this.usuarios = usuarios;
        this.peliculas = peliculas;
    }

    // Recomendación simple: películas con mayor rating promedio
    public List<Pelicula> recomendar(int userId, int cantidad) {
        boolean tieneRatings = false;
            for (int[] r : ratings.getAll()) {
                if (r[0] == userId) {  // si el user aparece en la matriz
                    tieneRatings = true;
                    break;
                }
            }

            if (!tieneRatings) {
                return new ArrayList<>();
            }

        Map<Integer, Double> sum = new HashMap<>();
        Map<Integer, Integer> count = new HashMap<>();

        for (int[] r : ratings.getAll()) {
            int movie = r[1];
            double rating = r[2];

            sum.put(movie, sum.getOrDefault(movie, 0.0) + rating);
            count.put(movie, count.getOrDefault(movie, 0) + 1);
        }

        // Calcular promedios
        List<Map.Entry<Integer, Double>> promedios = new ArrayList<>();
        for (int movieId : sum.keySet()) {
            double prom = sum.get(movieId) / count.get(movieId);
            promedios.add(Map.entry(movieId, prom));
        }

        // Ordenar por promedio descendente
        promedios.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        List<Pelicula> recomendadas = new ArrayList<>();

        for (Map.Entry<Integer, Double> e : promedios) {
            int movieId = e.getKey();

            // Evitar recomendar películas ya calificadas
            if (!ratings.exists(userId, movieId)) {
                recomendadas.add(peliculas.get(movieId));
            }

            if (recomendadas.size() == cantidad)
                break;
        }

        return recomendadas;
    }
}