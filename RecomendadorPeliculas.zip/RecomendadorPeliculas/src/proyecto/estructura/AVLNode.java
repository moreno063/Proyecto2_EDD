package proyecto.estructura;

import proyecto.modelos.Pelicula;

public class AVLNode {
    public Pelicula pelicula;
    public AVLNode left, right;
    public int height;

    public AVLNode(Pelicula pelicula) {
        this.pelicula = pelicula;
        this.height = 1;
    }
}
