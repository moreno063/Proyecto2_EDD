package proyecto.estructura;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SparseMatrix {

    // Cada elemento almacenará: fila = usuario, columna = película, valor = rating
    private static class Element {
        int userId;
        int movieId;
        double rating;

        Element(int userId, int movieId, double rating) {
            this.userId = userId;
            this.movieId = movieId;
            this.rating = rating;
        }
    }

    private final List<Element> elements;

    public SparseMatrix() {
        this.elements = new ArrayList<>();
    }

    // Añadir o actualizar un rating en la matriz
    public void add(int userId, int movieId, double rating) {

        for (Element e : elements) {
            if (e.userId == userId && e.movieId == movieId) {
                e.rating = rating; // actualiza si ya existe
                return;
            }
        }

        elements.add(new Element(userId, movieId, rating));
    }

    // Obtener un rating dado usuario y película
    public double get(int userId, int movieId) {
        for (Element e : elements) {
            if (e.userId == userId && e.movieId == movieId) {
                return e.rating;
            }
        }
        return 0.0; // significa "no existe"
    }

    // Ver si hay rating de un usuario hacia una película
    public boolean exists(int userId, int movieId) {
        for (Element e : elements) {
            if (e.userId == userId && e.movieId == movieId) {
                return true;
            }
        }
        return false;
    }

    // Obtener todos los ratings registrados
    public List<int[]> getAll() {
        List<int[]> lista = new ArrayList<>();
        for (Element e : elements) {
            int usuario = e.userId;
            int pelicula = e.movieId;
            int rating = (int) Math.round(e.rating); // redondea al entero más cercano
            lista.add(new int[] { usuario, pelicula, rating });
        }
        return lista;
    }
}