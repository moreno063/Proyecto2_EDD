package proyecto.estructura;

import proyecto.modelos.Pelicula;
import java.util.ArrayList;
import java.util.List;

public class AVLTree {
    private AVLNode root;

    // comparar por titulo (puede cambiar a id)
    private int cmp(Pelicula a, Pelicula b) {
        return a.getTitulo().compareToIgnoreCase(b.getTitulo());
    }

    private int height(AVLNode n) {
        return n == null ? 0 : n.height;
    }

    private int balanceFactor(AVLNode n) {
        return n == null ? 0 : height(n.left) - height(n.right);
    }

    private void updateHeight(AVLNode n) {
        n.height = 1 + Math.max(height(n.left), height(n.right));
    }

    private AVLNode rotateRight(AVLNode y) {
        AVLNode x = y.left;
        AVLNode T2 = x.right;
        x.right = y;
        y.left = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    private AVLNode rotateLeft(AVLNode x) {
        AVLNode y = x.right;
        AVLNode T2 = y.left;
        y.left = x;
        x.right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    public void insertar(Pelicula p) {
        root = insertar(root, p);
    }

    private AVLNode insertar(AVLNode node, Pelicula p) {
        if (node == null)
            return new AVLNode(p);
        int c = cmp(p, node.pelicula);
        if (c < 0)
            node.left = insertar(node.left, p);
        else if (c > 0)
            node.right = insertar(node.right, p);
        else {
            // mismo título -> podrías manejar por ID o ignorar
            return node;
        }

        updateHeight(node);
        int bf = balanceFactor(node);

        // cuatro casos
        if (bf > 1 && cmp(p, node.left.pelicula) < 0)
            return rotateRight(node);
        if (bf < -1 && cmp(p, node.right.pelicula) > 0)
            return rotateLeft(node);
        if (bf > 1 && cmp(p, node.left.pelicula) > 0) {
            node.left = rotateLeft(node.left);
            return rotateRight(node);
        }
        if (bf < -1 && cmp(p, node.right.pelicula) < 0) {
            node.right = rotateRight(node.right);
            return rotateLeft(node);
        }
        return node;
    }

    public Pelicula buscarPorTitulo(String titulo) {
        AVLNode cur = root;
        while (cur != null) {
            int c = titulo.compareToIgnoreCase(cur.pelicula.getTitulo());
            if (c == 0)
                return cur.pelicula;
            cur = c < 0 ? cur.left : cur.right;
        }
        return null;
    }

    public List<Pelicula> inOrder() {
        List<Pelicula> res = new ArrayList<>();
        inOrder(root, res);
        return res;
    }

    private void inOrder(AVLNode node, List<Pelicula> out) {
        if (node == null)
            return;
        inOrder(node.left, out);
        out.add(node.pelicula);
        inOrder(node.right, out);
    }

    // eliminar: puedes implementarlo si lo necesitas (no incluido por brevedad)

    public void eliminarPelicula(String titulo) {
        root = eliminar(root, titulo);
    }

    private AVLNode eliminar(AVLNode node, String titulo) {
        if (node == null)
            return null;

        int cmp = titulo.compareToIgnoreCase(node.pelicula.getTitulo());

        if (cmp < 0) {
            node.left = eliminar(node.left, titulo);
        } else if (cmp > 0) {
            node.right = eliminar(node.right, titulo);
        } else {
            // Nodo encontrado
            if (node.left == null || node.right == null) {
                AVLNode temp = (node.left != null) ? node.left : node.right;
                node = (temp != null) ? temp : null;
            } else {
                // Nodo con dos hijos: encontrar sucesor
                AVLNode sucesor = minimo(node.right);
                node.pelicula = sucesor.pelicula;
                node.right = eliminar(node.right, sucesor.pelicula.getTitulo());
            }
        }

        if (node == null)
            return null;

        // Actualizar altura y balancear
        node.height = 1 + Math.max(height(node.left), height(node.right));
        int balance = balanceFactor(node);

        // Rotaciones de balance
        if (balance > 1 && balanceFactor(node.left) >= 0)
            return rotateRight(node);
        if (balance > 1 && balanceFactor(node.left) < 0) {
            node.left = rotateLeft(node.left);
            return rotateRight(node);
        }
        if (balance < -1 && balanceFactor(node.right) <= 0)
            return rotateLeft(node);
        if (balance < -1 && balanceFactor(node.right) > 0) {
            node.right = rotateRight(node.right);
            return rotateLeft(node);
        }

        return node;
    }

    private AVLNode minimo(AVLNode node) {
        AVLNode current = node;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }

}