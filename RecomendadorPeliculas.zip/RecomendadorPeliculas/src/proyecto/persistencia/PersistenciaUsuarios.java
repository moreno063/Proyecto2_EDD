package proyecto.persistencia;

import java.io.*;
import java.util.*;
import proyecto.modelos.Usuario;

public class PersistenciaUsuarios {

    private String archivo;

    public PersistenciaUsuarios(String archivo) {
        this.archivo = archivo;
    }

    public void guardarUsuarios(List<Usuario> usuarios) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Usuario u : usuarios) {
                bw.write(u.getId() + ";" +
                        u.getNombre() + ";" +
                        (u.getGeneroFavorito() == null ? "" : u.getGeneroFavorito()));
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error guardando usuarios: " + e.getMessage());
        }
    }

    public List<Usuario> cargarUsuarios() {
        List<Usuario> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;

            while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(";");

                int id = Integer.parseInt(partes[0]);
                String nombre = partes[1];
                String generoFav = partes.length >= 3 ? partes[2] : "";

                lista.add(new Usuario(id, nombre, generoFav));
            }

        } catch (FileNotFoundException e) {
            System.out.println("Archivo usuarios.txt no existe. Se creará al guardar.");
        } catch (IOException e) {
            System.out.println("Error cargando usuarios: " + e.getMessage());
        }

        return lista;
    }

    public void crearArchivoSiNoExiste() {
        try {
            File f = new File(archivo);
            if (!f.exists()) {
                f.createNewFile();
                System.out.println("Archivo creado: " + archivo);
            }
        } catch (IOException e) {
            System.out.println("Error creando archivo: " + archivo);
        }
    }
}