package proyecto.persistencia;

import java.io.*;
import proyecto.estructura.SparseMatrix;
import java.util.*;

public class PersistenciaRating {

    private String archivo;

    public PersistenciaRating(String archivo) {
        this.archivo = archivo;
    }

    public void crearArchivoSiNoExiste() {
        try {
            File f = new File(archivo);
            if (!f.exists()) {
                f.createNewFile();
                System.out.println("Archivo creado: " + archivo);
            }
        } catch (IOException e) {
            System.out.println("Error creando archivo: " + archivo);
        }
    }

    public void guardarRatings(SparseMatrix matriz) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            List<int[]> lista = matriz.getAll();
            // Cada int[] es {usuario, pelicula, rating}

            for (int[] r : lista) {
                bw.write(r[0] + ";" + r[1] + ";" + r[2]);
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error guardando ratings: " + e.getMessage());
        }
    }

    // ESTA ES LA FIRMA CORRECTA (SIN PARÁMETROS)
    public SparseMatrix cargarRatings() {
        SparseMatrix matriz = new SparseMatrix();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                int u = Integer.parseInt(partes[0]);
                int p = Integer.parseInt(partes[1]);
                int r = Integer.parseInt(partes[2]);

                matriz.add(u, p, r);
            }

        } catch (FileNotFoundException e) {
            System.out.println("Archivo ratings.txt no existe.");
        } catch (IOException e) {
            System.out.println("Error cargando ratings: " + e.getMessage());
        }

        return matriz;
    }
}