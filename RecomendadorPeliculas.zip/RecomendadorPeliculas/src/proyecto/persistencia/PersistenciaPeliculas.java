package proyecto.persistencia;

import java.io.*;
import java.util.*;
import proyecto.modelos.Pelicula;

public class PersistenciaPeliculas {

    private String archivo;

    public PersistenciaPeliculas(String archivo) {
        this.archivo = archivo;
    }

    public void guardarPeliculas(List<Pelicula> peliculas) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Pelicula p : peliculas) {
                bw.write(p.getId() + ";" +
                        p.getTitulo() + ";" +
                        p.getGenero() + ";" +
                        p.getAnio());
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error guardando películas: " + e.getMessage());
        }
    }

    public List<Pelicula> cargarPeliculas() {
        List<Pelicula> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;

            while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(";");

                int id = Integer.parseInt(partes[0]);
                String titulo = partes[1];
                String genero = partes[2];
                int anio = Integer.parseInt(partes[3]);

                lista.add(new Pelicula(id, titulo, genero, anio));
            }

        } catch (FileNotFoundException e) {
            System.out.println("Archivo peliculas.txt no existe.");
        } catch (IOException e) {
            System.out.println("Error cargando películas: " + e.getMessage());
        }

        return lista;
    }

    public void crearArchivoSiNoExiste() {
        try {
            File f = new File(archivo);
            if (!f.exists()) {
                f.createNewFile();
                System.out.println("Archivo creado: " + archivo);
            }
        } catch (IOException e) {
            System.out.println("Error creando archivo: " + archivo);
        }
    }
}